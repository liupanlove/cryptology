利用BM算法可以得到：  
f(x) = 1 + x + x^2 + x^4 + x^5
l = 7

运行BM.cpp可得

step 0: 1  
l = 0  
step 1: 1  
l = 0  
step 2: 1  
l = 0  
step 3: 1  
l = 3  
step 4: 1  
l = 3  
step 5: 1 + x^2  
l = 3  
step 6: 1 + x^2  
l = 3  
step 7: 1 + x^2  
l = 3  
step 8: 1 + x^2  
l = 3  
step 9: 1 + x^2  
l = 6  
step 10: 1 + x^1 + x^2 + x^3  
l = 6  
step 11: 1 + x^1 + x^2 + x^3  
l = 6  
step 12: 1 + x^1 + x^2 + x^5  
l = 6  
step 13: 1 + x^1 + x^2 + x^4 + x^5  
l = 7  
step 14: 1 + x^1 + x^2 + x^4 + x^5  
l = 7  